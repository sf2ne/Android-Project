/**
 * Team Name: T103-18
 * Tame Computing IDs:
 *  Sadiyah Faruk: sf2ne
 *  Maggie Negm: mhn5et
 *  Agnes Kim: ak5nt
 *  Tiffany Kim: hk7mu
 *
 *  Sources Where Code was Cited from:
 *  http://android.bigresource.com/Android-Need-to-Calculate-Time-Elapsed-while-developing-game-bBPuo1f4g.html
 *  http://stackoverflow.com/questions/5191099/how-to-set-relativelayout-layout-params-in-code-not-in-xml
 *  http://developer.android.com/reference/android/view/ViewGroup.MarginLayoutParams.html#ViewGroup.MarginLayoutParams(int, int)
 *  http://stackoverflow.com/questions/5191099/how-to-set-relativelayout-layout-params-in-code-not-in-xml
 *  http://stackoverflow.com/questions/14930059/removing-an-imageview-from-view
 *  http://stackoverflow.com/questions/17364219/how-can-i-set-images-randomly-in-the-imageview-and-gridview-from-the-res-drawabl
 *  http://stackoverflow.com/questions/19028990/android-imageview-in-random-position-with-onclicklistener
 */

package cs2110.virginia.edu.ghostapp3;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.app.Activity;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import android.support.v7.internal.widget.ActionBarOverlayLayout;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.EditText;
import android.widget.TextView;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.media.AudioManager;
import android.content.Context;
import android.app.ActivityManager;
import java.util.List;
import android.content.ComponentName;


public class MainActivity extends ActionBarActivity {

    Rect userBox;
    RelativeLayout layout;
    ImageView userImage;
    private int userHealth;
    MediaPlayer mp;
    private SoundPool sound;
    int bombsnd = 0;
    int gunsnd = 0;
    Timer ghostTimer;
    Ghost ghost1;
    Ghost ghost2;
    Ghost ghost3;
    Ghost ghost4;
    Ghost ghost5;
    ArrayList<Ghost> ghosts = new ArrayList<Ghost>();
    private final int LAYOUT_WIDTH = 800;
    private final int LAYOUT_HEIGHT = 900;
    private final int MIN = 50;
    ImageView coin1;
    ImageView coin2;
    ImageView coin3;
    ImageView coin4;
    ImageView coin5;
    ImageView apple;
    ImageView heart;
    ImageView bomb1;
    ImageView bomb2;
    ImageView bomb3;
    ImageView bomb4;
    ImageView bomb5;
    ImageView megabomb;
    int userMoney;
    TextView health;
    TextView moneyAmount;
    ImageView coin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setUp();
        mp = MediaPlayer.create(MainActivity.this, R.raw.track);
        mp.setLooping(true);
        mp.start();
        sound = new SoundPool(99, AudioManager.STREAM_MUSIC, 0);
        gunsnd = sound.load(this, R.raw.shotgunsound, 1);
    }

    public void loot(Ghost ghost){
        float x = ghost.getX();
        float y = ghost.getY();
        coin = (ImageView)findViewById(R.id.coin);
        coin.setX(x);
        coin.setY(y);
        moneySystem(coin);
    }

    @Override
    protected void onPause() {
        if (this.isFinishing()) {
            mp.stop();
        }
        Context context = getApplicationContext();
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> taskInfo = am.getRunningTasks(1);
        if (!taskInfo.isEmpty()) {
            ComponentName topActivity = taskInfo.get(0).topActivity;
            if (!topActivity.getPackageName().equals(context.getPackageName())) {
                mp.stop();
            } else {
            }
        }
        super.onPause();
    }


    public void setUp() {
        layout = (RelativeLayout) findViewById(R.id.layout);
        userImage = (ImageView)findViewById(R.id.user);
        userBox = new Rect((int)userImage.getX(),(int)userImage.getY(), ((int)userImage.getX()+25), ((int)userImage.getY()+25));
        Random gen = new Random();
        userHealth = 100;
        health = (TextView) findViewById(R.id.health);
        health.setText("" + userHealth);

        bomb1 = (ImageView)findViewById(R.id.bomb1);
        bomb1.setX(gen.nextInt(LAYOUT_WIDTH));
        bomb1.setY(gen.nextInt(LAYOUT_HEIGHT));

        bomb2 = (ImageView)findViewById(R.id.bomb2);
        bomb2.setX(gen.nextInt(LAYOUT_WIDTH));
        bomb2.setY(gen.nextInt(LAYOUT_HEIGHT));

        bomb3 = (ImageView)findViewById(R.id.bomb3);
        bomb3.setX(gen.nextInt(LAYOUT_WIDTH));
        bomb3.setY(gen.nextInt(LAYOUT_HEIGHT));

        bomb4 = (ImageView)findViewById(R.id.bomb4);
        bomb4.setX(gen.nextInt(LAYOUT_WIDTH));
        bomb4.setY(gen.nextInt(LAYOUT_HEIGHT));

        bomb5 = (ImageView)findViewById(R.id.bomb5);
        bomb5.setX(gen.nextInt(LAYOUT_WIDTH));
        bomb5.setY(gen.nextInt(LAYOUT_HEIGHT));

        megabomb = (ImageView)findViewById(R.id.megabomb);
        megabomb.setX(gen.nextInt(LAYOUT_WIDTH));
        megabomb.setY(gen.nextInt(LAYOUT_HEIGHT));

        userMoney = 0;
        moneyAmount = (TextView) findViewById(R.id.money);
        moneyAmount.setText("" + userMoney);

        coin1 = (ImageView) findViewById(R.id.coin1);
        coin1.setX(gen.nextInt(LAYOUT_WIDTH));
        coin1.setY(gen.nextInt(LAYOUT_HEIGHT));

        coin2 = (ImageView) findViewById(R.id.coin2);
        coin2.setX(gen.nextInt(LAYOUT_WIDTH));
        coin2.setY(gen.nextInt(LAYOUT_HEIGHT));

        coin3 = (ImageView) findViewById(R.id.coin3);
        coin3.setX(gen.nextInt(LAYOUT_WIDTH));
        coin3.setY(gen.nextInt(LAYOUT_HEIGHT));

        coin4 = (ImageView) findViewById(R.id.coin4);
        coin4.setX(gen.nextInt(LAYOUT_WIDTH));
        coin4.setY(gen.nextInt(LAYOUT_HEIGHT));

        coin5 = (ImageView) findViewById(R.id.coin5);
        coin5.setX(gen.nextInt(LAYOUT_WIDTH));
        coin5.setY(gen.nextInt(LAYOUT_HEIGHT));

        apple = (ImageView)findViewById(R.id.apple);
        apple.setX(gen.nextInt(LAYOUT_WIDTH-50));
        apple.setY(gen.nextInt(LAYOUT_HEIGHT-50));


        // LET'S MAKE SOME GHOSTS
        int x1 = gen.nextInt(LAYOUT_WIDTH);
        int y1 = gen.nextInt(LAYOUT_HEIGHT);
        ghost1 = new Ghost(this);
        ghost1.create(x1, y1, 10, layout);
        ghosts.add(ghost1);
        Log.w("gethere","ghostmade");

        int x2 = gen.nextInt(LAYOUT_WIDTH);
        int y2 = gen.nextInt(LAYOUT_HEIGHT);
        ghost2 = new Ghost(this);
        ghost2.create(x2, y2, 10, layout);
        ghosts.add(ghost2);
        Log.w("gethere","ghostmade");

        int x3 = gen.nextInt(LAYOUT_WIDTH);
        int y3 = gen.nextInt(LAYOUT_HEIGHT);
        ghost3 = new Ghost(this);
        ghost3.create(x3, y3, 10, layout);
        ghosts.add(ghost3);
        Log.w("gethere","ghostmade");

        int x4 = gen.nextInt(LAYOUT_WIDTH);
        int y4 = gen.nextInt(LAYOUT_HEIGHT);
        ghost4 = new Ghost(this);
        ghost4.create(x4, y4, 10, layout);
        ghosts.add(ghost4);
        Log.w("gethere","ghostmade");

        int x5 = gen.nextInt(LAYOUT_WIDTH);
        int y5 = gen.nextInt(LAYOUT_HEIGHT);
        ghost5 = new Ghost(this);
        ghost5.create(x5, y5, 10, layout);
        ghosts.add(ghost5);
        Log.w("gethere","ghostmade");

        //Log.w("gethere", "createghost");
        ghostTimer = new Timer();
        ghostTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                TimerMethod();
            }
        }, 0, 500);//can change 1000milliseconds to 500 to have it move every 1/2 second
        Log.w("gethere","startingOnTouchListener");
        layout.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                userImage.setX((int)event.getX());
                userImage.setY((int)event.getY());
                userBox.set((int)userImage.getX(),(int)userImage.getY(), ((int)userImage.getX()+15), ((int)userImage.getY()+15));
                moneySystem(coin1);
                moneySystem(coin2);
                moneySystem(coin3);
                moneySystem(coin4);
                moneySystem(coin5);
                proximity(ghosts);
              //  heart();
                apple();
                collidesGhost(ghost1);
                collidesGhost(ghost2);
                collidesGhost(ghost3);
                collidesGhost(ghost4);
                collidesGhost(ghost5);
                collidesGhost(ghost1);
                collidesGhost(ghost2);
                collidesGhost(ghost3);
                collidesGhost(ghost4);
                collidesGhost(ghost5);
               // heart();
                apple();
                bomb(bomb1);
                bomb(bomb2);
                bomb(bomb3);
                bomb(bomb4);
                bomb(bomb5);
                megaBomb(megabomb);

                end();

                return true;
            }
        });
        Log.w("gethere", "usermoving");

        Log.w("gethere","endofoncreate");
    }

    public void bomb(ImageView bomb){
        if(userBox.intersects((int)bomb.getX(), (int)bomb.getY(), ((int)bomb.getX()+15), ((int)bomb.getY()+15))){
            loot(ghosts.get(0));
            Ghost.kill(ghosts.get(0));
            bomb.setVisibility(View.GONE);
        }
    }

    public void megaBomb(ImageView megaBomb){
        if(userBox.intersects((int)megaBomb.getX(), (int)megaBomb.getY(), ((int)megaBomb.getX()+15), ((int)megaBomb.getY()+15))){
            for(int i = 0; i < ghosts.size(); i++){
                loot(ghosts.get(i));
                Ghost.kill(ghosts.get(i));
            }
            megaBomb.setVisibility(View.GONE);
        }
    }

    public void heart(){
        Random gen = new Random();
        if(userMoney > 20) {
            heart = (ImageView) findViewById(R.id.heart);
            heart.setX(gen.nextInt(LAYOUT_WIDTH - 50));
            heart.setY(gen.nextInt(LAYOUT_HEIGHT - 50));
        }

        if(userBox.intersects((int)heart.getX(), (int)heart.getY(), ((int)heart.getX()+15), ((int)heart.getY()+15))){
            userHealth = userHealth + 50;
            heart.setVisibility(View.GONE);
        }
    }

    public void apple(){
        if(userBox.intersects((int)apple.getX(), (int)apple.getY(), ((int)apple.getX()+15), ((int)apple.getY()+15))){
            userHealth = userHealth + 30;
            apple.setVisibility(View.GONE);
        }
    }

    // KEEPING THOSE GHOST BOOTYS MOVING
    public void TimerMethod() {
        this.runOnUiThread(Timer_Tick);
        Log.w("gethere","timermethod");
    }

    public void collidesGhost(Ghost ghost){
        boolean test = Rect.intersects(userBox, ghost.getGhostBox());
        if(test){
            userHealth = userHealth - 20;
            health.setText("" + userHealth);
        }
    }

    private Runnable Timer_Tick = new Runnable() {
        public void run() {
            for(int j = 0; j < ghosts.size(); j++){
                if((ghosts.get(j).getX()>=LAYOUT_WIDTH) || (ghosts.get(j).getX()<= MIN)){
                    ghosts.get(j).setSpeed((-1)*ghosts.get(j).getSpeed());
                } else if((ghosts.get(j).getY()>=LAYOUT_HEIGHT) || (ghosts.get(j).getY()<= MIN)){
                    ghosts.get(j).setSpeed((-1)*ghosts.get(j).getSpeed());
                }
                ghosts.get(j).setY((int) ghosts.get(j).getY() + ghosts.get(j).getSpeed());
                ghosts.get(j).setX((int) ghosts.get(j).getX() + ghosts.get(j).getSpeed());
            }
            Log.w("gethere","ghostshouldbemoving");
        }
    };

    public void moneySystem(ImageView coin){
        if(userBox.intersects((int)coin.getX(), (int)coin.getY(), ((int)coin.getX()+15), ((int)coin.getY()+15))){
            userMoney = userMoney + 10;
            coin.setVisibility(View.GONE);
            moneyAmount.setText("" + userMoney);
        }
    }

    public void proximity(ArrayList<Ghost> ghosts) {
        float dangerX = userBox.centerX() + 40; // user cannot get within 5 of ghost
        float dangerY = userBox.centerY() + 40; // box width = 50
        Toast warningMsg = Toast.makeText(getApplicationContext(), "You're getting way too close!",
                Toast.LENGTH_SHORT);

        for(int i = 0; i < ghosts.size(); i++) {
            if(ghosts.get(i).getX() >= userBox.centerX() && ghosts.get(i).getY() >= userBox.centerY() &&
                    ghosts.get(i).getX() <= dangerX && ghosts.get(i).getY() <= dangerY) { // NE
                warningMsg.show();
            } else if(ghosts.get(i).getX() <= userBox.centerX() && ghosts.get(i).getY() >= userBox.centerY()
                    && ghosts.get(i).getX() >= dangerX && ghosts.get(i).getY() <= dangerY) { // NW
                warningMsg.show();
            } else if(ghosts.get(i).getX() >= userBox.centerX() && ghosts.get(i).getY() <= userBox.centerY()
                    && ghosts.get(i).getX() <= dangerX && ghosts.get(i).getY() >= dangerY) { // SE
                warningMsg.show();
            } else if(ghosts.get(i).getX() <= userBox.centerX() && ghosts.get(i).getY() <= userBox.centerY()
                    && ghosts.get(i).getX() >= dangerX && ghosts.get(i).getY() >= dangerY) { // SW
                warningMsg.show();
            } else {

            }
        }
    }

    public void end() {
        if(userHealth == 0) {
            System.exit(0);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void playGun(View view) {
        sound.play(gunsnd, 1, 1, 1, 1, 1); //change second to last to 3 if you want to play 3 times, change to 5f is the speed
    }

    public void changeLevelSlow(View view) {
        ghost1.setSpeed(10);
        ghost2.setSpeed(10);
        ghost3.setSpeed(10);
        ghost4.setSpeed(10);
        ghost5.setSpeed(10);
    }

    public void changeLevelMedium(View view) {
        ghost1.setSpeed(30);
        ghost2.setSpeed(30);
        ghost3.setSpeed(30);
        ghost4.setSpeed(30);
        ghost5.setSpeed(30);
    }

    public void changeLevelFast(View view) {
        ghost1.setSpeed(60);
        ghost2.setSpeed(60);
        ghost3.setSpeed(60);
        ghost4.setSpeed(60);
        ghost5.setSpeed(60);
    }
}

class Ghost {

    //FIELDS
    private float x;
    private float y;

    private int speed;
    ImageView ghostImage;
    Activity activity;
    RelativeLayout layout;
    Rect ghostBox;

    public Ghost(Activity activity) {
        this.activity = activity;
    }

    public void create(int x, int y, int speed, RelativeLayout layout) {
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.layout = layout;
        ghostBox = new Rect((int)this.x, (int)this.y, (int)this.x+15, (int)this.y+15);
        ghostImage = new ImageView(activity);
        ghostImage.setImageResource(R.drawable.ghost);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins((int)this.x, (int)this.y, 0, 0);
        ghostImage.setLayoutParams(params);
        layout.addView(ghostImage);
    }

    public void update(int x, int y, int speed, RelativeLayout layout){
        this.x = x;
        this.y = y;
        this.speed = speed;
        this.layout = layout;
        ghostBox.set((int)this.x, (int)this.y, (int)this.x+15, (int)this.y+15);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins((int) this.x, (int) this.y, 0, 0);
        ghostImage.setLayoutParams(params);
    }

    public static boolean kill(Ghost ghost){
        ImageView gImage = ghost.getGhostImage();
        gImage.setVisibility(View.GONE);
        return true;
    }



    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public ImageView getGhostImage() {return this.ghostImage;}

    public int getSpeed(){
        return this.speed;
    }

    public Rect getGhostBox(){
        return this.ghostBox;
    }

    public int getBoxX(){
        return this.ghostBox.width();
    }

    public int getBoxY(){
        return this.ghostBox.height();
    }

    public boolean setX(int x){
        this.x = x;
        update((int) this.x, (int) this.y, this.speed, this.layout);
        return true;
    }

    public boolean setY(int y){
        this.y = y;
        update((int) this.x, (int) this.y, this.speed, this.layout);
        return true;
    }

    public boolean setSpeed(int speed){
        this.speed = speed;
        update((int) this.x, (int) this.y, this.speed, this.layout);
        return true;
    }
}




